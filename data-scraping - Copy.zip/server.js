const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Create SQLite database connection with error handling
const dbPath = path.join(__dirname, 'database.sqlite');
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Database connection error:', err);
    } else {
        console.log('Connected to SQLite database');
    }
});

// Initialize database table with error handling
db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS form_data (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        data TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`, (err) => {
        if (err) {
            console.error('Table creation error:', err);
        } else {
            console.log('Database table ready');
        }
    });
});

// Handle process termination
process.on('SIGINT', () => {
    db.close((err) => {
        if (err) {
            console.error('Error closing database:', err);
        } else {
            console.log('Database connection closed');
        }
        process.exit(0);
    });
});

app.post('/submit-form', (req, res) => {
    const formData = JSON.stringify(req.body);
    
    db.run('INSERT INTO form_data (data) VALUES (?)', [formData], (err) => {
        if (err) {
            console.error('Error saving data:', err);
            return res.status(500).json({ error: 'Failed to save data' });
        }
        res.json({ message: 'Data saved successfully' });
    });
});

app.get('/get-data', (req, res) => {
    db.all('SELECT * FROM form_data', [], (err, rows) => {
        if (err) {
            console.error('Error fetching data:', err);
            return res.status(500).json({ error: 'Failed to fetch data' });
        }
        
        // Parse the JSON strings back to objects
        const data = rows.map(row => ({
            ...row,
            data: JSON.parse(row.data)
        }));
        
        res.json(data);
    });
});