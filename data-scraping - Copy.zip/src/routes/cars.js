const express = require('express');
const router = express.Router();
const { carSchema, carUpdateSchema } = require('../models/car');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const multer = require('multer');

// Create SQLite database connection with error handling
const dbPath = path.join(__dirname, '..', '..', 'database.sqlite');
const db = new sqlite3.Database(dbPath, sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, (err) => {
    if (err) {
        console.error('Database connection error:', err.message);
        process.exit(1);
    }
    console.log('Connected to SQLite database');
});

// Handle database errors
db.on('error', (err) => {
    console.error('Database error:', err.message);
});

// Initialize cars table with error handling
db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS cars (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        brand TEXT,
        model TEXT,
        year INTEGER,
        price REAL,
        image_url TEXT,
        specifications TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`, (err) => {
        if (err) {
            console.error('Table creation error:', err.message);
            process.exit(1);
        }
        console.log('Cars table ready');
    });
});

// Handle process termination
process.on('SIGINT', () => {
    db.close((err) => {
        if (err) {
            console.error('Error closing database:', err.message);
        } else {
            console.log('Database connection closed');
        }
        process.exit(0);
    });
});

// Get all cars
router.get('/', (req, res) => {
    db.all('SELECT * FROM cars', [], (err, rows) => {
        if (err) {
            return res.status(500).json({ message: 'Error fetching cars' });
        }
        res.json(rows);
    });
});

// Get car by id
router.get('/:id', (req, res) => {
    const id = parseInt(req.params.id);
    db.get('SELECT * FROM cars WHERE id = ?', [id], (err, row) => {
        if (err) {
            return res.status(500).json({ message: 'Error fetching car' });
        }
        if (!row) {
            return res.status(404).json({ message: 'Car not found' });
        }
        
        // Parse the specifications JSON string back to an object
        try {
            if (row.specifications) {
                row.specifications = JSON.parse(row.specifications);
            }
        } catch (error) {
            console.error('Error parsing specifications:', error);
            row.specifications = {};
        }
        
        res.json(row);
    });
});

// Add new car with image
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/')
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname)
    }
});

const upload = multer({ 
    storage: storage,
    fileFilter: (req, file, cb) => {
        if (file.mimetype.startsWith('image/')) {
            cb(null, true);
        } else {
            cb(new Error('Not an image! Please upload an image.'));
        }
    }
});

// Remove multer configuration since we're not handling file uploads anymore

// Update the POST route to handle image URL and specifications
router.post('/', (req, res) => {
    const carData = {
        brand: req.body.brand,
        model: req.body.model,
        year: parseInt(req.body.year),
        price: parseFloat(req.body.price),
        image_url: req.body.image_url,
        specifications: req.body.specifications
    };

    const { error } = carSchema.validate(carData);
    if (error) {
        return res.status(400).json({ message: error.details[0].message });
    }

    // First, update the table to include specifications column if it doesn't exist
    db.run(`ALTER TABLE cars ADD COLUMN specifications TEXT`, (err) => {
        // Ignore error if column already exists
        
        // Convert specifications object to JSON string for storage
        const specificationsJson = JSON.stringify(carData.specifications);

        db.run(
            'INSERT INTO cars (brand, model, year, price, image_url, specifications) VALUES (?, ?, ?, ?, ?, ?)',
            [carData.brand, carData.model, carData.year, carData.price, carData.image_url, specificationsJson],
            function(err) {
                if (err) {
                    console.error('Insert error:', err);
                    return res.status(500).json({ message: 'Error saving car' });
                }
                
                // Parse specifications back to object for response
                const responseData = {
                    id: this.lastID,
                    ...carData,
                    specifications: carData.specifications
                };
                
                res.status(201).json(responseData);
            }
        );
    });
});

// Update car
// Update car by ID
router.put('/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const { brand, model, year, price, image_url } = req.body;

    // Check if at least one field is provided
    if (!brand && !model && !year && !price && !image_url) {
        return res.status(400).json({ message: 'At least one field must be provided for update' });
    }

    // Build update query dynamically
    const updates = [];
    const values = [];
    
    if (brand) {
        updates.push('brand = ?');
        values.push(brand);
    }
    if (model) {
        updates.push('model = ?');
        values.push(model);
    }
    if (year) {
        updates.push('year = ?');
        values.push(parseInt(year));
    }
    if (price) {
        updates.push('price = ?');
        values.push(parseFloat(price));
    }
    if (image_url) {
        updates.push('image_url = ?');
        values.push(image_url);
    }

    // Add id to values array
    values.push(id);

    const sql = `UPDATE cars SET ${updates.join(', ')} WHERE id = ?`;

    db.run(sql, values, function(err) {
        if (err) {
            console.error('Update error:', err);
            return res.status(500).json({ message: 'Error updating car' });
        }
        if (this.changes === 0) {
            return res.status(404).json({ message: 'Car not found' });
        }
        
        // Fetch and return the updated car
        db.get('SELECT * FROM cars WHERE id = ?', [id], (err, car) => {
            if (err) {
                return res.status(500).json({ message: 'Error fetching updated car' });
            }
            res.json(car);
        });
    });
});

// Delete car
// Delete single car by ID
router.delete('/:id', (req, res) => {
    const id = parseInt(req.params.id);
    db.run('DELETE FROM cars WHERE id = ?', [id], function(err) {
        if (err) {
            return res.status(500).json({ message: 'Error deleting car' });
        }
        if (this.changes === 0) {
            return res.status(404).json({ message: 'Car not found' });
        }
        res.json({ message: 'Car deleted successfully' });
    });
});

// Delete multiple cars by IDs
router.delete('/', (req, res) => {
    const { ids } = req.body;
    if (!ids || !Array.isArray(ids)) {
        return res.status(400).json({ message: 'Invalid request body' });
    }

    const placeholders = ids.map(() => '?').join(',');
    db.run(`DELETE FROM cars WHERE id IN (${placeholders})`, ids, function(err) {
        if (err) {
            return res.status(500).json({ message: 'Error deleting cars' });
        }
        res.json({ message: `${this.changes} cars deleted successfully` });
    });
});

// Delete cars by brand and model
router.delete('/filter', (req, res) => {
    const { brand, model } = req.body;
    db.run('DELETE FROM cars WHERE brand = ? AND model = ?', [brand, model], function(err) {
        if (err) {
            return res.status(500).json({ message: 'Error deleting cars' });
        }
        res.json({ message: `${this.changes} cars deleted successfully` });
    });
});
module.exports = router;