const express = require('express');
const app = express();
const cors = require('cors');
const carsRouter = require('./routes/cars');

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/cars', carsRouter);

const port = process.env.PORT || 5000;

// Start server with proper error handling
const startServer = () => {
    const server = app.listen(port)
        .on('listening', () => {
            console.log(`Server running on port ${port}`);
        })
        .on('error', (err) => {
            if (err.code === 'EADDRINUSE') {
                console.log(`Port ${port} is busy, trying ${port + 1}`);
                port++;
                startServer();
            } else {
                console.error('Server error:', err);
            }
        });
};

startServer();

// Error handling
process.on('uncaughtException', (err) => {
    console.error('Uncaught Exception:', err);
    process.exit(1);
});

process.on('unhandledRejection', (err) => {
    console.error('Unhandled Rejection:', err);
    process.exit(1);
});