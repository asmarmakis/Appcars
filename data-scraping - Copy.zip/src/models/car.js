const Joi = require('joi');

const carSchema = Joi.object({
    brand: Joi.string().required().messages({
        'string.empty': 'Brand cannot be empty',
        'any.required': 'Brand is required'
    }),
    model: Joi.string().required().messages({
        'string.empty': 'Model cannot be empty',
        'any.required': 'Model is required'
    }),
    year: Joi.number().integer().min(1900).max(2024).required().messages({
        'number.base': 'Year must be a number',
        'number.min': 'Year must be 1900 or later',
        'number.max': 'Year cannot be in the future',
        'any.required': 'Year is required'
    }),
    price: Joi.number().positive().required().messages({
        'number.base': 'Price must be a number',
        'number.positive': 'Price must be positive',
        'any.required': 'Price is required'
    }),
    image_url: Joi.alternatives().try(
        // For URLs
        Joi.string().uri(),
        // For local file paths
        Joi.string().pattern(/\.(jpg|jpeg|png|gif)$/i),
        // For base64 images
        Joi.string().pattern(/^data:image\/(jpg|jpeg|png|gif);base64,/)
    ).required().messages({
        'any.required': 'Image URL or file is required',
        'alternatives.match': 'Please provide a valid image URL, file path (ending with .jpg, .jpeg, .png, or .gif), or base64 image string'
    }),
    specifications: Joi.object({
        engine: Joi.object({
            type: Joi.string().required(),
            displacement: Joi.number().positive().required(),
            horsepower: Joi.number().positive().required(),
            torque: Joi.number().positive().required(),
            transmission: Joi.string().required()
        }).required(),
        dimensions: Joi.object({
            length: Joi.number().positive().required(),
            width: Joi.number().positive().required(),
            height: Joi.number().positive().required(),
            wheelbase: Joi.number().positive().required()
        }).required(),
        performance: Joi.object({
            acceleration: Joi.number().positive().required(),
            topSpeed: Joi.number().positive().required(),
            fuelConsumption: Joi.number().positive().required()
        }).required()
    }).required().messages({
        'any.required': 'Specifications are required'
    })
});

const cars = [];

module.exports = {
    carSchema,
    cars
};